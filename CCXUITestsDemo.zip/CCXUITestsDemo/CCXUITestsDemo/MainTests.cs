﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System.Text.RegularExpressions;
using OpenQA.Selenium.Interactions;
using System.Collections.Generic;
using System.Linq;
using CCXUITestsDemo.Model;
using log4net;
using Microsoft.Test.VisualVerification;
using System.IO;
using System.Drawing.Imaging;
using System.Drawing;

namespace CCXUITestsDemo
{
    [TestClass]
    public class MainTests
    {
        private static ILog logger = LogManager.GetLogger(typeof(MainTests));

        IWebDriver driver;
        private static TestContext testContext;
        private static int waitForAjax = 3000;
        private static string browser = "";
        private static string startUrl = "";

        public LogInModel CurrentUser { get; set; }

        public TenderModel CreateTenderModel { get; set; }

        [ClassInitialize]
        public static void SetupTests(TestContext context)
        {
            testContext = context;
            log4net.Config.XmlConfigurator.Configure();
        }

        [TestInitialize]
        public void TestChromeSetup()
        {
            startUrl = testContext.Properties["Url"].ToString();
            browser = testContext.Properties["TargetBrowser"].ToString();
        }

        [TestCleanup]
        public void Cleanup()
        {
            driver.Close();
            driver.Quit();
        }
        
        #region Tests

        [TestMethod]
        public void Test_LogIn()
        {
            logger.Info("Start Test_LogIn test");
            switch (browser)
            {
                case "ie":
                    RunIELoginTest();
                    break;
                case "ff":
                    RunFireFoxLoginTest();
                    break;
                default:
                    RunChromeLoginTest();
                    break;
            };
            //driver.SwitchTo().Frame(driver.FindElements(By.TagName("iframe"))[0]);
            //FindAndOpenTenderWizard(_tenderRef);
            //driver.SwitchTo().DefaultContent();
            //NavigateOnTenderWizardToParticularStepAndCheckResult();
        }

        [TestMethod]
        public void Test_Create_Tender()
        {
            logger.Info("Start Test_Create_Tender test");
            switch (browser)
            {
                case "ie":
                    RunIECreateTenderTest();
                    break;
                case "ff":
                    RunFireFoxCreateTenderTestt();
                    break;
                default:
                    RunChromeCreateTenderTest();
                    break;
            };
        }

        //[TestMethod]
        //public void Test_Create_Master_Screenshot()
        //{
        //    SetupChromeEnvironment();
        //    LogOut();
        //    SetUpVerifyScreensTestSettings();
        //    CloseCompatibilityModeWindow();
        //    LogInCurrentUser();
        //    SelectEnglishLanguage();
        //    WaitForLoad(driver);

        //    driver.SwitchTo().Frame(driver.FindElements(By.TagName("iframe"))[0]);

        //    IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

        //    var filterBtn = driver.FindElement(By.XPath("//*[@id='filterButton-btnEl']"));
        //    executor.ExecuteScript("arguments[0].click();", filterBtn);

        //    var filterTitle = driver.FindElement(By.XPath("//*[@id='filtertdrInfo-inputEl']"));
        //    filterTitle.SendKeys("VLD_#rc0.1.0.3618e_s03_T11");

        //    var applyFilter = driver.FindElement(By.XPath("//*[@id='button-1037-btnEl']"));
        //    executor.ExecuteScript("arguments[0].click();", applyFilter);

        //    WaitForAjax();

        //    executor.ExecuteScript("arguments[0].click();", filterBtn);

        //    Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
        //    ss.SaveAsFile("f:\\temp\\uitests\\master-diff.png", ScreenshotImageFormat.Png);
        //}

        //[TestMethod]
        //public void Test_Create_Master_Create_Tender_First_Step_Screenshot()
        //{
        //    SetupChromeEnvironment();
        //    LogOut();
        //    SetUpVerifyScreensTestSettings();
        //    CloseCompatibilityModeWindow();
        //    LogInCurrentUser();
        //    SelectEnglishLanguage();
        //    WaitForLoad(driver);

        //    driver.SwitchTo().Frame(driver.FindElements(By.TagName("iframe"))[0]);

        //    System.Threading.Thread.Sleep(5000);

        //    IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

        //    var filterBtn = driver.FindElement(By.XPath("//*[@id='filterButton-btnEl']"));
        //    executor.ExecuteScript("arguments[0].click();", filterBtn);
        //    var filterRef = driver.FindElement(By.XPath("//*[@id='filterRef-inputEl']"));
        //    filterRef.SendKeys(CurrentUser.VerifyScreensTenderRef);
        //    var applyFilter = driver.FindElement(By.XPath("//*[@id='button-1037-btnEl']"));
        //    executor.ExecuteScript("arguments[0].click();", applyFilter);
        //    WaitForAjax();
        //    executor.ExecuteScript("arguments[0].click();", filterBtn);

        //    driver.SwitchTo().DefaultContent();

        //    OpenCreateTenderWindow();



        //    string workPath = testContext.Properties["ScreenPath"].ToString();

        //    Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
        //    ss.SaveAsFile("f:\\temp\\uitests\\master_shipper_create_tender_1_step.png", ScreenshotImageFormat.Png);
        //}

        [TestMethod]
        public void Test_Verify_Shipper_All_Tender_Screen()
        {
            logger.Info("Start Test_Verify_Shipper_All_Tender_Screen Test.");
            SetupChromeEnvironment();
            LogOut();
            SetUpVerifyScreensTestSettings();
            CloseCompatibilityModeWindow();
            LogInCurrentUser();
            SelectEnglishLanguage();
            WaitForLoad(driver);

            System.Threading.Thread.Sleep(5000);

            driver.SwitchTo().Frame(driver.FindElements(By.TagName("iframe"))[0]);
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            var filterBtn = driver.FindElement(By.XPath("//*[@id='filterButton-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", filterBtn);
            var filterRef = driver.FindElement(By.XPath("//*[@id='filterRef-inputEl']"));
            filterRef.SendKeys(CurrentUser.VerifyScreensTenderRef);
            var applyFilter = driver.FindElement(By.XPath("//*[@id='button-1037-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", applyFilter);
            WaitForAjax();
            executor.ExecuteScript("arguments[0].click();", filterBtn);

            string workPath = testContext.Properties["ScreenPath"].ToString();
            Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
            ss.SaveAsFile(Path.Combine(workPath, "actual_shipper_tender_all.png"), ScreenshotImageFormat.Png);

            Snapshot master = Snapshot.FromFile(Path.Combine(workPath, "master_shipper_tender_all.png"));
            Snapshot actual = Snapshot.FromFile(Path.Combine(workPath, "actual_shipper_tender_all.png"));
            Snapshot difference = actual.CompareTo(master);
            SnapshotVerifier v = new SnapshotColorVerifier(Color.Black, new ColorDifference());
            if (v.Verify(difference) == VerificationResult.Fail)
            {
                difference.ToFile(Path.Combine(workPath, "difference_shipper_tender_all.png"), ImageFormat.Png);
            }
        }

        [TestMethod]
        public void Test_Verify_Shipper_Create_Tender_First_Step_Screen()
        {
            logger.Info("Start Test_Verify_Shipper_Create_Tender_First_Step_Screen Test.");
            SetupChromeEnvironment();
            LogOut();
            SetUpVerifyScreensTestSettings();
            CloseCompatibilityModeWindow();
            LogInCurrentUser();
            SelectEnglishLanguage();
            WaitForLoad(driver);

            System.Threading.Thread.Sleep(5000);

            driver.SwitchTo().Frame(driver.FindElements(By.TagName("iframe"))[0]);
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            var filterBtn = driver.FindElement(By.XPath("//*[@id='filterButton-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", filterBtn);
            var filterRef = driver.FindElement(By.XPath("//*[@id='filterRef-inputEl']"));
            filterRef.SendKeys(CurrentUser.VerifyScreensTenderRef);
            var applyFilter = driver.FindElement(By.XPath("//*[@id='button-1037-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", applyFilter);
            WaitForAjax();
            executor.ExecuteScript("arguments[0].click();", filterBtn);

            string workPath = testContext.Properties["ScreenPath"].ToString();

            driver.SwitchTo().DefaultContent();

            OpenCreateTenderWindow();

            System.Threading.Thread.Sleep(3000);

            Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
            ss.SaveAsFile(Path.Combine(workPath, "actual_shipper_create_tender_1_step.png"), ScreenshotImageFormat.Png);

            Snapshot master = Snapshot.FromFile(Path.Combine(workPath, "master_shipper_create_tender_1_step.png"));
            Snapshot actual = Snapshot.FromFile(Path.Combine(workPath, "actual_shipper_create_tender_1_step.png"));
            Snapshot difference = actual.CompareTo(master);
            SnapshotVerifier v = new SnapshotColorVerifier(Color.Black, new ColorDifference());
            if (v.Verify(difference) == VerificationResult.Fail)
            {
                difference.ToFile(Path.Combine(workPath, "difference_shipper_create_tender_1_step.png"), ImageFormat.Png);
            }
        }

        [TestMethod]
        public void Test_Create_Shipper_Create_Tender_First_Step_Screen()
        {
            SetupChromeEnvironment();
            LogOut();
            SetUpVerifyScreensTestSettings();
            CloseCompatibilityModeWindow();
            LogInCurrentUser();
            SelectEnglishLanguage();
            WaitForLoad(driver);

            System.Threading.Thread.Sleep(5000);

            driver.SwitchTo().Frame(driver.FindElements(By.TagName("iframe"))[0]);
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            var filterBtn = driver.FindElement(By.XPath("//*[@id='filterButton-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", filterBtn);
            var filterRef = driver.FindElement(By.XPath("//*[@id='filterRef-inputEl']"));
            filterRef.SendKeys(CurrentUser.VerifyScreensTenderRef);
            var applyFilter = driver.FindElement(By.XPath("//*[@id='button-1037-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", applyFilter);
            WaitForAjax();
            executor.ExecuteScript("arguments[0].click();", filterBtn);

            string workPath = testContext.Properties["ScreenPath"].ToString();

            driver.SwitchTo().DefaultContent();

            OpenCreateTenderWindow();

            System.Threading.Thread.Sleep(3000);

            Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();
            ss.SaveAsFile(Path.Combine(workPath, "master_shipper_create_tender_1_step.png"), ScreenshotImageFormat.Png);
        }

        #endregion

        private void RunTheMeasureMethod(string actionName, Action func)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            func();
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            var res = (double)elapsedMs / 1000;
            if (res > 10)
            {
                logger.Info(string.Format("#Warning '{0}' took quite a long time: {1} sec!", actionName, res.ToString()));
            }
        }
        private static void WaitForLoad(IWebDriver driver, string actionName, int timeoutSec = 15)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            var waitForDocumentReady = new WebDriverWait(driver, new TimeSpan(0, 0, timeoutSec));
            waitForDocumentReady.Until((wdriver) => (driver as IJavaScriptExecutor).ExecuteScript("return document.readyState").Equals("complete"));
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            var res = (double)elapsedMs / 1000;
            if (res > 10)
            {
                logger.Info(string.Format("#Warning '{0}' took quite a long time: {1} sec!", actionName, res.ToString()));
            }
        }
        private static void WaitForLoad(IWebDriver driver, int timeoutSec = 15)
        {
            var waitForDocumentReady = new WebDriverWait(driver, new TimeSpan(0, 0, timeoutSec));
            waitForDocumentReady.Until((wdriver) => (driver as IJavaScriptExecutor).ExecuteScript("return document.readyState").Equals("complete"));
        }
        private void WaitForAjax()
        {
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(waitForAjax));
            wait.Until(d => (bool)(d as IJavaScriptExecutor).ExecuteScript("return !Ext.Ajax.isLoading();"));
            System.Threading.Thread.Sleep(3000);
        }
        private void WaitForAjax(string actionName)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(waitForAjax));
            wait.Until(d => (bool)(d as IJavaScriptExecutor).ExecuteScript("return !Ext.Ajax.isLoading();"));
           // System.Threading.Thread.Sleep(1000);
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            var res = (double)elapsedMs / 1000;
            if (res > 10)
            {
                logger.Info(string.Format("#Warning '{0}' took quite a long time: {1} sec!", actionName, res.ToString()));
            }
        }
        private void LogOut()
        {
            if (IsElementExists(By.XPath("//*[@id='btnLogout-btnInnerEl']")))
            {
                IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                var btn = driver.FindElement(By.XPath("//*[@id='btnLogout-btnInnerEl']"));
                executor.ExecuteScript("arguments[0].click();", btn);
            }
        }
        private void CheckIsShipperTenderAllTabExist()
        {
            var tab = driver.FindElement(By.XPath("//*[@id='tab-1020-btnInnerEl']"));
            Assert.AreEqual(tab.Text, "Shipper tenders(all)");
        }
        private void SelectEnglishLanguage()
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            Actions action = new Actions(driver);

            var acctBtn = driver.FindElement(By.XPath("//*[@id='mmAccount-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", acctBtn);

            var menuElement = driver.FindElement(By.XPath("//*[@id='mmCtl24-itemEl']"));
            action.MoveToElement(menuElement).Perform();

            var eng = driver.FindElement(By.XPath("//*[@id='2-itemEl']"));
            executor.ExecuteScript("arguments[0].click();", eng);
        }       
        private void CheckChromeBrowserSettings()
        {
            // check browser version
            string version = ((ChromeDriver)driver).Capabilities.Version;
            int ver = 0;
            Int32.TryParse(version.Substring(0, version.IndexOf(".")), out ver);
            Assert.IsTrue(ver > 41);
        }
        private void CheckIEBrowserSettings()
        {
            // check browser version
            string version = ((InternetExplorerDriver)driver).Capabilities.Version;
            int ver = 0;
            Int32.TryParse(version, out ver);
            Assert.IsTrue(ver >= 11);
        }
        private void CheckFireFoxBrowserSettings()
        {
            // check browser version
            string version = ((FirefoxDriver)driver).Capabilities.GetCapability("browserVersion").ToString();
            int ver = 0;
            Int32.TryParse(version.Substring(0, version.IndexOf(".")), out ver);
            Assert.IsTrue(ver >= 50);
        }
        private void CloseCompatibilityModeWindow()
        {
            if (IsElementExists(By.XPath("//*[@id='button-1042-btnEl']")))
            {
                var btn = driver.FindElement(By.XPath("//*[@id='button-1042-btnEl']"));
                if(btn.Displayed)
                    btn.Click();
            }
        }
        private bool IsElementExists(By by)
        {
            var items = driver.FindElements(by);
            return items.Count > 0;
        }
        public void SetupIEEnvironment()
        {
            InternetExplorerOptions opt = new InternetExplorerOptions();
            driver = new InternetExplorerDriver(opt);
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            RunTheMeasureMethod("Go to the start URL", delegate () { driver.Navigate().GoToUrl(startUrl); });
        }   
        public void SetupFireFoxEnvironment()
        {
            FirefoxOptions opt = new FirefoxOptions();
            opt.SetPreference("intl.accept_languages", "en");
            driver = new FirefoxDriver(opt);
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            RunTheMeasureMethod("Go to the start URL", delegate () { driver.Navigate().GoToUrl(startUrl); });
        }
        public void SetupChromeEnvironment()
        {
            ChromeOptions opt = new ChromeOptions();
            opt.AddArguments("---lang=en");
            opt.AddArguments("test-type");
            opt.AddArguments("start-maximized");
            opt.AddArguments("--disable-extensions");
            opt.AddArguments("no-sandbox");
            driver = new ChromeDriver(opt);
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            RunTheMeasureMethod("Go to the start URL", delegate () { driver.Navigate().GoToUrl(startUrl); });
            driver.Navigate().GoToUrl(startUrl);
        }
        private void CheckStartLoadingForm()
        {
            bool isCompatibilityWindowShown = IsElementExists(By.XPath("//*[@id='CompatibilityWindow-body']"));
            Assert.IsFalse(isCompatibilityWindowShown);

            bool isLoginWindowShown = IsElementExists(By.XPath("//*[@id='LoginWindow-body']"));
            Assert.IsTrue(isCompatibilityWindowShown);
        }
        private void LogInCurrentUser()
        {
            var txtUserName = driver.FindElement(By.XPath("//*[@id='txtUsername-inputEl']"));
            var txtPassword = driver.FindElement(By.XPath("//*[@id='txtPassword-inputEl']"));
            var btn = driver.FindElement(By.XPath("//*[@id='LoginButton-btnEl']"));

            txtUserName.Clear();
            txtUserName.SendKeys(CurrentUser.UserName);
            txtPassword.Clear();
            txtPassword.SendKeys(CurrentUser.Password);
          
            var watch = System.Diagnostics.Stopwatch.StartNew();
            btn.Click();
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            var res = (double)elapsedMs / 1000;
            if (res > 10)
            {
                logger.Info(string.Format("#Warning '{0}' took quite a long time: {1} sec!", "Log In Click", res.ToString()));
            }
        }
        private void CreateTender()
        {
            OpenCreateTenderWindow();
            WaitForAjax("Create tender");
            CreateTenderProcessStep1();
            WaitForAjax();
            CreateTenderProcessStep2();
            WaitForAjax();
            CreateTenderProcessStep3();
            WaitForAjax();
            CreateTenderProcessStep4();
            WaitForAjax();
            CreateTenderProcessStep5();
            WaitForAjax();
            CreateTenderProcessStep6();
            WaitForAjax();
            CreateTenderProcessStep7();
            WaitForAjax();
            CreateTenderProcessStep8();
            WaitForAjax();
            CreateTenderProcessStep9();
        }
        private void OpenCreateTenderWindow()
        {
            // use js executor as click have problem in IE
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            var menu = driver.FindElement(By.XPath("//*[@id='mmTenders-btnInnerEl']"));
            executor.ExecuteScript("arguments[0].click();", menu);
            //menu.Click();
            var createLink = driver.FindElement(By.XPath("//*[@id='mmStartTender']"));
            executor.ExecuteScript("arguments[0].click();", createLink);
            //createLink.Click();
        }
        private void CreateTenderProcessStep1()
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

            var headerDiv = driver.FindElement(By.Id("tenderWizardDlg_header-innerCt"));
            var fullScreen = headerDiv.FindElements(By.TagName("div"))[0].FindElements(By.TagName("img"))[0];
            executor.ExecuteScript("arguments[0].click();", fullScreen);

            var title = driver.FindElement(By.XPath("//*[@id='Title-inputEl']"));
            var num = driver.FindElement(By.XPath("//*[@id='TenderNumber-inputEl']"));
            var internalMemo = driver.FindElement(By.XPath("//*[@id='InternalTitle-inputEl']"));
            var startDate = driver.FindElement(By.XPath("//*[@id='StartTenderDate-inputEl']"));
            var endDate = driver.FindElement(By.XPath("//*[@id='EndTenderDate-inputEl']"));
            var startCollaborationitle = driver.FindElement(By.XPath("//*[@id='StartCollaboration-inputEl']"));
            var finishCollaboration = driver.FindElement(By.XPath("//*[@id='FinishCollaboration-inputEl']"));

            title.SendKeys(CreateTenderModel.TenderTiltle_Step1);
            num.SendKeys(CreateTenderModel.TenderNumber_Step1);
            internalMemo.SendKeys(CreateTenderModel.InternalMemo_Step1);
            endDate.SendKeys(startDate.GetAttribute("value"));
            System.Threading.Thread.Sleep(100);

            IList<IWebElement> comboItems;
            var awarding = driver.FindElement(By.XPath("//*[@id='AwardCombo-inputEl']"));
            executor.ExecuteScript("arguments[0].click();", awarding);
            //awarding.Click();
            comboItems = driver.FindElements(By.ClassName("x-boundlist-item"));
            var c1 = comboItems.First(item => item.Text.Trim() == CreateTenderModel.Awarding_Step1);
            executor.ExecuteScript("arguments[0].click();", c1);
            //comboItems.First(item => item.Text.Trim() == CreateTenderModel.Awarding_Step1).Click();

            startCollaborationitle.SendKeys(startDate.GetAttribute("value"));
            System.Threading.Thread.Sleep(100);

            finishCollaboration.SendKeys(startDate.GetAttribute("value"));
            System.Threading.Thread.Sleep(100);

            var target = driver.FindElement(By.XPath("//*[@id='ReasonCombo-inputEl']"));
            executor.ExecuteScript("arguments[0].click();", target);
            //target.Click();
            comboItems = driver.FindElements(By.ClassName("x-boundlist-item"));
            var c2 = comboItems.First(item => item.Text.Trim() == CreateTenderModel.TargerForTendering_Step1);
            executor.ExecuteScript("arguments[0].click();", c2);
            //comboItems.First(item => item.Text.Trim() == CreateTenderModel.TargerForTendering_Step1).Click();
            
            System.Threading.Thread.Sleep(1000);
            var next = driver.FindElement(By.XPath("//*[@id='button-1029-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", next);
            //next.Click();
        }
        private void CreateTenderProcessStep2()
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

            var title = driver.FindElement(By.XPath("//*[@id='tenderWizardDlg_header_hd-textEl']"));
            Assert.AreEqual(title.Text, string.Format("Starting new tender - Tender settings - Step 2/9 ({0})", CreateTenderModel.TenderTiltle_Step1));

            var next = driver.FindElement(By.XPath("//*[@id='button-1029-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", next);
        }
        private void CreateTenderProcessStep3()
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

            var title = driver.FindElement(By.XPath("//*[@id='tenderWizardDlg_header_hd-textEl']"));
            Assert.AreEqual(title.Text, string.Format("Starting new tender - Freight - Step 3/9 ({0})", CreateTenderModel.TenderTiltle_Step1));

            var freightHeadline = driver.FindElement(By.XPath("//*[@id='Destination-inputEl']"));
            freightHeadline.SendKeys(CreateTenderModel.FreightHeadline_Step3);

            var next = driver.FindElement(By.XPath("//*[@id='button-1029-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", next);
        }
        private void CreateTenderProcessStep4()
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

            var title = driver.FindElement(By.XPath("//*[@id='tenderWizardDlg_header_hd-textEl']"));
            Assert.AreEqual(title.Text, string.Format("Starting new tender - Transport - Step 4/9 ({0})", CreateTenderModel.TenderTiltle_Step1));

            var roadCheckbox = driver.FindElement(By.XPath("//*[@id='checkboxfield-1145-inputEl']"));
            executor.ExecuteScript("arguments[0].click();", roadCheckbox);

            var next = driver.FindElement(By.XPath("//*[@id='button-1029-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", next);
        }
        private void CreateTenderProcessStep5()
        {
            System.Threading.Thread.Sleep(10000);

            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

            var title = driver.FindElement(By.XPath("//*[@id='tenderWizardDlg_header_hd-textEl']"));
            Assert.AreEqual(title.Text, string.Format("Starting new tender - Bidding matrix - Step 5/9 ({0})", CreateTenderModel.TenderTiltle_Step1));

            executor.ExecuteScript("objShippingMatrix.Content.ShippingMatrixClient.ImportTestMatrix('Default.ccx');");
            System.Threading.Thread.Sleep(10000);

            executor.ExecuteScript("objShippingMatrix.Content.ShippingMatrixClient.SaveMatrix();");
            System.Threading.Thread.Sleep(10000);

            var next = driver.FindElement(By.XPath("//*[@id='button-1029-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", next);
        }
        private void CreateTenderProcessStep6()
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

            var title = driver.FindElement(By.XPath("//*[@id='tenderWizardDlg_header_hd-textEl']"));
            Assert.AreEqual(title.Text, string.Format("Starting new tender - Service providers - Step 6/9 ({0})", CreateTenderModel.TenderTiltle_Step1));

            var formPanel = driver.FindElement(By.XPath("//*[@id='SubmitFormPanel-body']"));
            var btn = formPanel.FindElements(By.TagName("table"))[5].FindElements(By.TagName("tr"))[1].FindElements(By.TagName("td"))[0].FindElements(By.TagName("button"))[0];

            executor.ExecuteScript("arguments[0].click();", btn);
            System.Threading.Thread.Sleep(5000);

            var next = driver.FindElement(By.XPath("//*[@id='button-1029-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", next);
        }
        private void CreateTenderProcessStep7()
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

            var title = driver.FindElement(By.XPath("//*[@id='tenderWizardDlg_header_hd-textEl']"));
            Assert.AreEqual(title.Text, string.Format("Starting new tender - Notifications - Step 7/9 ({0})", CreateTenderModel.TenderTiltle_Step1));

            var ok = driver.FindElement(By.XPath("//*[contains(text(), 'OK')]"));
            executor.ExecuteScript("arguments[0].click();", ok);

            var next = driver.FindElement(By.XPath("//*[@id='button-1029-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", next);
        }
        private void CreateTenderProcessStep8()
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

            var title = driver.FindElement(By.XPath("//*[@id='tenderWizardDlg_header_hd-textEl']"));
            Assert.AreEqual(title.Text, string.Format("Starting new tender - Preconditions - Step 8/9 ({0})", CreateTenderModel.TenderTiltle_Step1));

            var privacyStatmentCheckbox = driver.FindElement(By.XPath("//*[@id='PrivacyStatmentFieldSet-legendChk-inputEl']"));
            executor.ExecuteScript("arguments[0].click();", privacyStatmentCheckbox);

            var next = driver.FindElement(By.XPath("//*[@id='button-1029-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", next);
        }
        private void CreateTenderProcessStep9()
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;

            var title = driver.FindElement(By.XPath("//*[@id='tenderWizardDlg_header_hd-textEl']"));
            Assert.AreEqual(title.Text, string.Format("Starting new tender - Finish - Step 9/9 ({0})", CreateTenderModel.TenderTiltle_Step1));

            var publishBtn = driver.FindElement(By.XPath("//*[@id='Publish-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", publishBtn);
            System.Threading.Thread.Sleep(3000);

            var acceptCheckbox = driver.FindElement(By.XPath("//*[@id='AcceptCheckboxBox-inputEl']"));
            executor.ExecuteScript("arguments[0].click();", acceptCheckbox);

            var saveBtn = driver.FindElement(By.XPath("//*[@id='SaveBtn-btnEl']"));
            executor.ExecuteScript("arguments[0].click();", saveBtn);
            System.Threading.Thread.Sleep(3000);

            var ok = driver.FindElement(By.XPath("//*[contains(text(), 'OK')]"));
            executor.ExecuteScript("arguments[0].click();", ok);         
        }

        private void SetUpLogInTestSettings()
        {
            BuildShipperUser();
        }
        private void SetUpVerifyScreensTestSettings()
        {
            BuildShipperUser();

        }
        private void SetUpCreateTenderTestSettings()
        {
            BuildShipperUser();

            CreateTenderModel = new TenderModel()
            {
                TenderTiltle_Step1 = "TestTenderTitle",
                TenderNumber_Step1 = "TestTenderNumber",
                InternalMemo_Step1 = "TestTenderInternalMemo",
                TenderDescription_Step1 = "TestTenderDescription",
                TargerForTendering_Step1 = "New business",
                Awarding_Step1 = "Award to a service provider",
                FreightHeadline_Step3 = "Freight Headline",
                FreightDescription_Step3 = "Freight Description"
            };
        }
        private void BuildShipperUser()
        {
            CurrentUser = new LogInModel() { UserName = "s03", Password = "admin", VerifyScreensTenderRef = "T1703131226" };
        }

        private void RunChromeCreateTenderTest()
        {
            SetupChromeEnvironment();
            LogOut();
            SetUpCreateTenderTestSettings();
            // Just for test TO DO remove CloseCompatibilityModeWindow from here
            CloseCompatibilityModeWindow();
            LogInCurrentUser();
            CreateTender();
            LogOut();
            WaitForLoad(driver);
        }
        private void RunIECreateTenderTest()
        {
            SetupIEEnvironment();
            LogOut();
            SetUpCreateTenderTestSettings();
            // Just for test TO DO remove CloseCompatibilityModeWindow from here
            CloseCompatibilityModeWindow();
            LogInCurrentUser();
            CreateTender();
            LogOut();
            WaitForLoad(driver);
        }
        private void RunFireFoxCreateTenderTestt()
        {
            SetupFireFoxEnvironment();
            LogOut();
            SetUpCreateTenderTestSettings();
            // Just for test TO DO remove CloseCompatibilityModeWindow from here
            CloseCompatibilityModeWindow();
            LogInCurrentUser();
            CreateTender();
            LogOut();
            WaitForLoad(driver);
        }

        private void RunChromeLoginTest()
        {
            SetupChromeEnvironment();
            LogOut();
            SetUpLogInTestSettings();
            CheckChromeBrowserSettings();
            //CheckStartLoadingForm();
            CloseCompatibilityModeWindow();
            LogInCurrentUser();
            CheckIsShipperTenderAllTabExist();
            var watch = System.Diagnostics.Stopwatch.StartNew();
            SelectEnglishLanguage();
            WaitForLoad(driver);
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            var res = (double)elapsedMs / 1000;
            if (res > 10)
            {
                logger.Info(string.Format("#Warning '{0}' took quite a long time: {1} sec!", "Change language", res.ToString()));
            }
            LogOut();
            WaitForLoad(driver);
        }
        private void RunFireFoxLoginTest()
        {
            SetupFireFoxEnvironment();
            LogOut();
            SetUpLogInTestSettings();
            CheckFireFoxBrowserSettings();
            //CheckStartLoadingForm();
            CloseCompatibilityModeWindow();
            LogInCurrentUser();
            CheckIsShipperTenderAllTabExist();
            var watch = System.Diagnostics.Stopwatch.StartNew();
            SelectEnglishLanguage();
            WaitForLoad(driver);
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            var res = (double)elapsedMs / 1000;
            if (res > 10)
            {
                logger.Info(string.Format("#Warning '{0}' took quite a long time: {1} sec!", "Change language", res.ToString()));
            }
            LogOut();
            WaitForLoad(driver);
        }
        private void RunIELoginTest()
        {
            SetupIEEnvironment();
            LogOut();
            SetUpLogInTestSettings();
            CheckIEBrowserSettings();
            //CheckStartLoadingForm();
            CloseCompatibilityModeWindow();
            LogInCurrentUser();
            CheckIsShipperTenderAllTabExist();
            var watch = System.Diagnostics.Stopwatch.StartNew();
            SelectEnglishLanguage();
            WaitForLoad(driver);
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            var res = (double)elapsedMs / 1000;
            if (res > 10)
            {
                logger.Info(string.Format("#Warning '{0}' took quite a long time: {1} sec!", "Change language", res.ToString()));
            }
            LogOut();
            WaitForLoad(driver);
        }
    }
}
